import React from 'react';
import TriangleCalculatorMaster from './components/TriangleCalculatorMaster';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
          Triangulator Master
        </h1>
        <TriangleCalculatorMaster />
      </div>
    </div>
  );
};

export default App;

// DONE