const TriangleCalculator = () => {
  const [sideA, setSideA] = useState('');
  const [sideB, setSideB] = useState('');
  const [sideC, setSideC] = useState('');
  const [angleA, setAngleA] = useState('');
  const [angleB, setAngleB] = useState('');
  const [angleC, setAngleC] = useState('');
  const [results, setResults] = useState(null);

  const calculateTriangle = () => {
    // Convertir valores a números
    const a = parseFloat(sideA);
    const b = parseFloat(sideB);
    const c = parseFloat(sideC);
    const angA = parseFloat(angleA);
    const angB = parseFloat(angleB);
    const angC = parseFloat(angleC);

    // Validaciones básicas
    if (a <= 0 || b <= 0 || c <= 0 || angA <= 0 || angB <= 0 || angC <= 0) {
      alert('Todos los valores deben ser mayores que cero');
      return;
    }

    // Calcular ángulos externos
    const extAngleA = 180 - angA;
    const extAngleB = 180 - angB;
    const extAngleC = 180 - angC;

    // Calcular perímetro
    const perimeter = a + b + c;

    // Calcular semiperímetro para el área (fórmula de Herón)
    const s = perimeter / 2;
    const area = Math.sqrt(s * (s - a) * (s - b) * (s - c));

    // Determinar tipo de triángulo
    let type = '';
    if (a === b && b === c) {
      type = 'Equilátero';
    } else if (a === b || b === c || a === c) {
      type = 'Isósceles';
    } else {
      type = 'Escaleno';
    }

    // Determinar por ángulos
    let angleType = '';
    if (angA < 90 && angB < 90 && angC < 90) {
      angleType = 'Acutángulo';
    } else if (angA === 90 || angB === 90 || angC === 90) {
      angleType = 'Rectángulo';
    } else {
      angleType = 'Obtusángulo';
    }

    setResults({
      sides: { a, b, c },
      internalAngles: { angA, angB, angC },
      externalAngles: { extAngleA, extAngleB, extAngleC },
      perimeter,
      area,
      type,
      angleType
    });
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Calculadora de Triángulos</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Lados</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado A</label>
              <input
                type="number"
                value={sideA}
                onChange={(e) => setSideA(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado B</label>
              <input
                type="number"
                value={sideB}
                onChange={(e) => setSideB(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado C</label>
              <input
                type="number"
                value={sideC}
                onChange={(e) => setSideC(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Ángulos Internos</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo A (grados)</label>
              <input
                type="number"
                value={angleA}
                onChange={(e) => setAngleA(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo B (grados)</label>
              <input
                type="number"
                value={angleB}
                onChange={(e) => setAngleB(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo C (grados)</label>
              <input
                type="number"
                value={angleC}
                onChange={(e) => setAngleC(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={calculateTriangle}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200"
      >
        Calcular Propiedades
      </button>

      {results && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-3">Resultados</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-700">Lados</h4>
              <ul className="mt-2 space-y-1">
                <li>A: {results.sides.a}</li>
                <li>B: {results.sides.b}</li>
                <li>C: {results.sides.c}</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Internos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo A: {results.internalAngles.angA}°</li>
                <li>Ángulo B: {results.internalAngles.angB}°</li>
                <li>Ángulo C: {results.internalAngles.angC}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Externos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo Externo A: {results.externalAngles.extAngleA}°</li>
                <li>Ángulo Externo B: {results.externalAngles.extAngleB}°</li>
                <li>Ángulo Externo C: {results.externalAngles.extAngleC}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Otras Propiedades</h4>
              <ul className="mt-2 space-y-1">
                <li>Perímetro: {results.perimeter}</li>
                <li>Área: {results.area.toFixed(2)}</li>
                <li>Tipo (lados): {results.type}</li>
                <li>Tipo (ángulos): {results.angleType}</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TriangleCalculator;