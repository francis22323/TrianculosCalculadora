import React, { useState } from 'react';

const TriangleCalculatorUltra = () => {
  const [inputs, setInputs] = useState({
    sideA: '',
    sideB: '',
    sideC: '',
    angleA: '',
    angleB: '',
    angleC: ''
  });
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputs(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const calculateTriangle = () => {
    setError('');
    const { sideA, sideB, sideC, angleA, angleB, angleC } = inputs;
    
    // Convertir valores a números
    const sides = {
      a: parseFloat(sideA) || null,
      b: parseFloat(sideB) || null,
      c: parseFloat(sideC) || null
    };

    const angles = {
      A: parseFloat(angleA) || null,
      B: parseFloat(angleB) || null,
      C: parseFloat(angleC) || null
    };

    // Validar que haya al menos 3 elementos
    const knownElements = Object.values(sides).filter(v => v !== null).length + 
                         Object.values(angles).filter(v => v !== null).length;
    
    if (knownElements < 3) {
      setError('Se necesitan al menos 3 valores conocidos');
      return;
    }

    try {
      // Calcular ángulos faltantes si hay suficientes datos
      if (angles.A && angles.B && !angles.C) {
        angles.C = 180 - angles.A - angles.B;
      } else if (angles.A && angles.C && !angles.B) {
        angles.B = 180 - angles.A - angles.C;
      } else if (angles.B && angles.C && !angles.A) {
        angles.A = 180 - angles.B - angles.C;
      }

      // Calcular lados usando Ley de Senos si es posible
      if (sides.a && angles.A) {
        if (!sides.b && angles.B) {
          sides.b = (sides.a * Math.sin(angles.B * Math.PI / 180)) / Math.sin(angles.A * Math.PI / 180);
        }
        if (!sides.c && angles.C) {
          sides.c = (sides.a * Math.sin(angles.C * Math.PI / 180)) / Math.sin(angles.A * Math.PI / 180);
        }
      }

      if (sides.b && angles.B) {
        if (!sides.a && angles.A) {
          sides.a = (sides.b * Math.sin(angles.A * Math.PI / 180)) / Math.sin(angles.B * Math.PI / 180);
        }
        if (!sides.c && angles.C) {
          sides.c = (sides.b * Math.sin(angles.C * Math.PI / 180)) / Math.sin(angles.B * Math.PI / 180);
        }
      }

      if (sides.c && angles.C) {
        if (!sides.a && angles.A) {
          sides.a = (sides.c * Math.sin(angles.A * Math.PI / 180)) / Math.sin(angles.C * Math.PI / 180);
        }
        if (!sides.b && angles.B) {
          sides.b = (sides.c * Math.sin(angles.B * Math.PI / 180)) / Math.sin(angles.C * Math.PI / 180);
        }
      }

      // Validar suma de ángulos
      if (angles.A && angles.B && angles.C) {
        const sum = angles.A + angles.B + angles.C;
        if (Math.abs(sum - 180) > 0.1) {
          throw new Error(`La suma de ángulos (${sum.toFixed(1)}°) no es 180°`);
        }
      }

      // Validar desigualdad triangular
      if (sides.a && sides.b && sides.c) {
        if (sides.a + sides.b <= sides.c || 
            sides.a + sides.c <= sides.b || 
            sides.b + sides.c <= sides.a) {
          throw new Error('Los lados no cumplen la desigualdad triangular');
        }
      }

      // Calcular propiedades adicionales
      const perimeter = sides.a && sides.b && sides.c ? sides.a + sides.b + sides.c : null;
      const s = perimeter ? perimeter / 2 : null;
      const area = s && sides.a && sides.b && sides.c ? 
        Math.sqrt(s * (s - sides.a) * (s - sides.b) * (s - sides.c)) : null;

      // Determinar tipo de triángulo
      let typeBySides = '';
      if (sides.a && sides.b && sides.c) {
        if (sides.a === sides.b && sides.b === sides.c) {
          typeBySides = 'Equilátero';
        } else if (sides.a === sides.b || sides.b === sides.c || sides.a === sides.c) {
          typeBySides = 'Isósceles';
        } else {
          typeBySides = 'Escaleno';
        }
      }

      let typeByAngles = '';
      if (angles.A && angles.B && angles.C) {
        if (angles.A < 90 && angles.B < 90 && angles.C < 90) {
          typeByAngles = 'Acutángulo';
        } else if (angles.A === 90 || angles.B === 90 || angles.C === 90) {
          typeByAngles = 'Rectángulo';
        } else {
          typeByAngles = 'Obtusángulo';
        }
      }

      // Calcular ángulos externos
      const extAngles = {
        A: angles.A ? 180 - angles.A : null,
        B: angles.B ? 180 - angles.B : null,
        C: angles.C ? 180 - angles.C : null
      };

      setResults({
        sides,
        angles,
        extAngles,
        perimeter,
        area,
        typeBySides,
        typeByAngles
      });

    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Calculadora de Triángulos Ultra</h2>
      
      {error && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">{error}</div>}

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Lados</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado a</label>
              <input
                type="number"
                name="sideA"
                value={inputs.sideA}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado b</label>
              <input
                type="number"
                name="sideB"
                value={inputs.sideB}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado c</label>
              <input
                type="number"
                name="sideC"
                value={inputs.sideC}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Ángulos (grados)</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo A</label>
              <input
                type="number"
                name="angleA"
                value={inputs.angleA}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo B</label>
              <input
                type="number"
                name="angleB"
                value={inputs.angleB}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo C</label>
              <input
                type="number"
                name="angleC"
                value={inputs.angleC}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={calculateTriangle}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200"
      >
        Calcular Propiedades
      </button>

      {results && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-3">Resultados</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-700">Lados</h4>
              <ul className="mt-2 space-y-1">
                <li>a: {results.sides.a?.toFixed(2) || 'Desconocido'}</li>
                <li>b: {results.sides.b?.toFixed(2) || 'Desconocido'}</li>
                <li>c: {results.sides.c?.toFixed(2) || 'Desconocido'}</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Internos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo A: {results.angles.A?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo B: {results.angles.B?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo C: {results.angles.C?.toFixed(1) || 'Desconocido'}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Externos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo Externo A: {results.extAngles.A?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo Externo B: {results.extAngles.B?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo Externo C: {results.extAngles.C?.toFixed(1) || 'Desconocido'}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Otras Propiedades</h4>
              <ul className="mt-2 space-y-1">
                <li>Perímetro: {results.perimeter?.toFixed(2) || 'Desconocido'}</li>
                <li>Área: {results.area?.toFixed(2) || 'Desconocido'}</li>
                {results.typeBySides && <li>Tipo (lados): {results.typeBySides}</li>}
                {results.typeByAngles && <li>Tipo (ángulos): {results.typeByAngles}</li>}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TriangleCalculatorUltra;