import React, { useState } from 'react';

const TriangleCalculatorMaster = () => {
  const [inputs, setInputs] = useState({
    sideA: '', sideB: '', sideC: '',
    angleA: '', angleB: '', angleC: ''
  });
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const calculateTriangle = () => {
    setError('');
    const { sideA, sideB, sideC, angleA, angleB, angleC } = inputs;
    
    // Convertir a números
    const sides = {
      a: sideA ? parseFloat(sideA) : null,
      b: sideB ? parseFloat(sideB) : null,
      c: sideC ? parseFloat(sideC) : null
    };

    const angles = {
      A: angleA ? parseFloat(angleA) : null,
      B: angleB ? parseFloat(angleB) : null,
      C: angleC ? parseFloat(angleC) : null
    };

    // Validar mínimo 3 elementos
    const knownCount = [...Object.values(sides), ...Object.values(angles)]
      .filter(val => val !== null).length;
    
    if (knownCount < 3) {
      setError('Ingresa al menos 3 valores (lados/ángulos)');
      return;
    }

    try {
      // Calcular ángulos faltantes
      const angleSum = angles.A && angles.B && angles.C 
        ? angles.A + angles.B + angles.C 
        : null;
      
      if (angles.A && angles.B && !angles.C) {
        angles.C = 180 - angles.A - angles.B;
      } else if (angles.A && angles.C && !angles.B) {
        angles.B = 180 - angles.A - angles.C;
      } else if (angles.B && angles.C && !angles.A) {
        angles.A = 180 - angles.B - angles.C;
      }

      // Calcular lados con Ley de Senos
      const calculateSide = (knownSide, knownAngle, targetAngle) => {
        return (knownSide * Math.sin(targetAngle * Math.PI / 180)) / 
               Math.sin(knownAngle * Math.PI / 180);
      };

      if (sides.a && angles.A) {
        if (!sides.b && angles.B) sides.b = calculateSide(sides.a, angles.A, angles.B);
        if (!sides.c && angles.C) sides.c = calculateSide(sides.a, angles.A, angles.C);
      }

      if (sides.b && angles.B) {
        if (!sides.a && angles.A) sides.a = calculateSide(sides.b, angles.B, angles.A);
        if (!sides.c && angles.C) sides.c = calculateSide(sides.b, angles.B, angles.C);
      }

      if (sides.c && angles.C) {
        if (!sides.a && angles.A) sides.a = calculateSide(sides.c, angles.C, angles.A);
        if (!sides.b && angles.B) sides.b = calculateSide(sides.c, angles.C, angles.B);
      }

      // Validar suma de ángulos
      if (angles.A && angles.B && angles.C) {
        const sum = angles.A + angles.B + angles.C;
        if (Math.abs(sum - 180) > 0.1) {
          throw new Error(`Suma de ángulos inválida: ${sum.toFixed(1)}°`);
        }
      }

      // Validar desigualdad triangular
      if (sides.a && sides.b && sides.c) {
        if (sides.a + sides.b <= sides.c || 
            sides.a + sides.c <= sides.b || 
            sides.b + sides.c <= sides.a) {
          throw new Error('Los lados no forman un triángulo válido');
        }
      }

      // Calcular propiedades
      const perimeter = sides.a && sides.b && sides.c 
        ? sides.a + sides.b + sides.c 
        : null;
      
      const s = perimeter ? perimeter / 2 : null;
      
      const area = s && sides.a && sides.b && sides.c
        ? Math.sqrt(s * (s - sides.a) * (s - sides.b) * (s - sides.c))
        : null;

      // Determinar tipos
      let typeBySides = '';
      if (sides.a && sides.b && sides.c) {
        if (sides.a === sides.b && sides.b === sides.c) {
          typeBySides = 'Equilátero';
        } else if (sides.a === sides.b || sides.b === sides.c || sides.a === sides.c) {
          typeBySides = 'Isósceles';
        } else {
          typeBySides = 'Escaleno';
        }
      }

      let typeByAngles = '';
      if (angles.A && angles.B && angles.C) {
        if (angles.A < 90 && angles.B < 90 && angles.C < 90) {
          typeByAngles = 'Acutángulo';
        } else if (angles.A === 90 || angles.B === 90 || angles.C === 90) {
          typeByAngles = 'Rectángulo';
        } else {
          typeByAngles = 'Obtusángulo';
        }
      }

      // Ángulos externos
      const extAngles = {
        A: angles.A ? 180 - angles.A : null,
        B: angles.B ? 180 - angles.B : null,
        C: angles.C ? 180 - angles.C : null
      };

      setResults({
        sides, angles, extAngles,
        perimeter, area,
        typeBySides, typeByAngles
      });

    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Triangulator Master</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Lados</h3>
          <div className="space-y-3">
            {['a', 'b', 'c'].map(side => (
              <div key={side}>
                <label className="block text-sm font-medium text-gray-600">
                  Lado {side.toUpperCase()}
                </label>
                <input
                  type="number"
                  name={`side${side.toUpperCase()}`}
                  value={inputs[`side${side.toUpperCase()}`]}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ingrese longitud"
                  min="0"
                  step="0.01"
                />
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Ángulos</h3>
          <div className="space-y-3">
            {['A', 'B', 'C'].map(angle => (
              <div key={angle}>
                <label className="block text-sm font-medium text-gray-600">
                  Ángulo {angle}
                </label>
                <input
                  type="number"
                  name={`angle${angle}`}
                  value={inputs[`angle${angle}`]}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ingrese ángulo"
                  min="0"
                  max="180"
                  step="0.1"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={calculateTriangle}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200"
      >
        Calcular Todo
      </button>

      {results && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-3">Resultados</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-700">Lados</h4>
              <ul className="mt-2 space-y-1">
                {['a', 'b', 'c'].map(side => (
                  <li key={side}>
                    {side.toUpperCase()}: {results.sides[side]?.toFixed(2) || 'Desconocido'}
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Internos</h4>
              <ul className="mt-2 space-y-1">
                {['A', 'B', 'C'].map(angle => (
                  <li key={angle}>
                    Ángulo {angle}: {results.angles[angle]?.toFixed(1) || 'Desconocido'}°
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Externos</h4>
              <ul className="mt-2 space-y-1">
                {['A', 'B', 'C'].map(angle => (
                  <li key={angle}>
                    Ext. {angle}: {results.extAngles[angle]?.toFixed(1) || 'Desconocido'}°
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Propiedades</h4>
              <ul className="mt-2 space-y-1">
                <li>Perímetro: {results.perimeter?.toFixed(2) || 'Desconocido'}</li>
                <li>Área: {results.area?.toFixed(2) || 'Desconocido'}</li>
                {results.typeBySides && <li>Tipo: {results.typeBySides}</li>}
                {results.typeByAngles && <li>Ángulos: {results.typeByAngles}</li>}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TriangleCalculatorMaster;