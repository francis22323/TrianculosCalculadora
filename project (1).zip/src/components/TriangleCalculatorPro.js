import React, { useState } from 'react';

const TriangleCalculatorPro = () => {
  const [sideA, setSideA] = useState('');
  const [sideB, setSideB] = useState('');
  const [sideC, setSideC] = useState('');
  const [angleA, setAngleA] = useState('');
  const [angleB, setAngleB] = useState('');
  const [angleC, setAngleC] = useState('');
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');

  const toRadians = (degrees) => degrees * Math.PI / 180;
  const toDegrees = (radians) => radians * 180 / Math.PI;

  const calculateMissingValues = () => {
    // Convertir valores a números
    const sides = {
      a: parseFloat(sideA) || null,
      b: parseFloat(sideB) || null,
      c: parseFloat(sideC) || null
    };

    const angles = {
      A: parseFloat(angleA) || null,
      B: parseFloat(angleB) || null,
      C: parseFloat(angleC) || null
    };

    // Validar que haya al menos 3 elementos conocidos
    const knownElements = [
      sides.a !== null, sides.b !== null, sides.c !== null,
      angles.A !== null, angles.B !== null, angles.C !== null
    ].filter(Boolean).length;

    if (knownElements < 3) {
      setError('Se necesitan al menos 3 elementos conocidos (lados/ángulos)');
      return null;
    }

    // Calcular ángulos faltantes si solo se conoce uno
    if (angles.A && !angles.B && !angles.C) {
      if (sides.a && sides.b && sides.c) {
        // Ley de cosenos para encontrar ángulos
        angles.B = toDegrees(Math.acos((sides.a2 + sides.c2 - sides.b2) / (2 * sides.a * sides.c));
        angles.C = 180 - angles.A - angles.B;
      }
    } else if (angles.B && !angles.A && !angles.C) {
      if (sides.a && sides.b && sides.c) {
        angles.A = toDegrees(Math.acos((sides.b2 + sides.c2 - sides.a2) / (2 * sides.b * sides.c));
        angles.C = 180 - angles.A - angles.B;
      }
    } else if (angles.C && !angles.A && !angles.B) {
      if (sides.a && sides.b && sides.c) {
        angles.A = toDegrees(Math.acos((sides.b2 + sides.c2 - sides.a2) / (2 * sides.b * sides.c)));
        angles.B = 180 - angles.A - angles.C;
      }
    }

    // Si tenemos dos ángulos, calcular el tercero
    if (angles.A && angles.B && !angles.C) {
      angles.C = 180 - angles.A - angles.B;
    } else if (angles.A && angles.C && !angles.B) {
      angles.B = 180 - angles.A - angles.C;
    } else if (angles.B && angles.C && !angles.A) {
      angles.A = 180 - angles.B - angles.C;
    }

    // Calcular lados faltantes usando Ley de Senos
    if (sides.a && angles.A) {
      if (!sides.b && angles.B) {
        sides.b = (sides.a * Math.sin(toRadians(angles.B))) / Math.sin(toRadians(angles.A));
      }
      if (!sides.c && angles.C) {
        sides.c = (sides.a * Math.sin(toRadians(angles.C))) / Math.sin(toRadians(angles.A));
      }
    }

    if (sides.b && angles.B) {
      if (!sides.a && angles.A) {
        sides.a = (sides.b * Math.sin(toRadians(angles.A))) / Math.sin(toRadians(angles.B));
      }
      if (!sides.c && angles.C) {
        sides.c = (sides.b * Math.sin(toRadians(angles.C))) / Math.sin(toRadians(angles.B));
      }
    }

    if (sides.c && angles.C) {
      if (!sides.a && angles.A) {
        sides.a = (sides.c * Math.sin(toRadians(angles.A))) / Math.sin(toRadians(angles.C));
      }
      if (!sides.b && angles.B) {
        sides.b = (sides.c * Math.sin(toRadians(angles.B))) / Math.sin(toRadians(angles.C));
      }
    }

    // Validar que la suma de ángulos sea 180
    if (angles.A && angles.B && angles.C) {
      const angleSum = Math.round(angles.A + angles.B + angles.C);
      if (angleSum !== 180) {
        setError(`La suma de ángulos (${angleSum}°) no es 180°`);
        return null;
      }
    }

    // Validar desigualdad triangular
    if (sides.a && sides.b && sides.c) {
      if (sides.a + sides.b <= sides.c || 
          sides.a + sides.c <= sides.b || 
          sides.b + sides.c <= sides.a) {
        setError('Los lados no cumplen con la desigualdad triangular');
        return null;
      }
    }

    // Calcular propiedades adicionales
    const perimeter = sides.a && sides.b && sides.c ? sides.a + sides.b + sides.c : null;
    const s = perimeter ? perimeter / 2 : null;
    const area = s && sides.a && sides.b && sides.c 
      ? Math.sqrt(s * (s - sides.a) * (s - sides.b) * (s - sides.c)) 
      : null;

    // Determinar tipo de triángulo
    let type = '';
    if (sides.a && sides.b && sides.c) {
      if (sides.a === sides.b && sides.b === sides.c) {
        type = 'Equilátero';
      } else if (sides.a === sides.b || sides.b === sides.c || sides.a === sides.c) {
        type = 'Isósceles';
      } else {
        type = 'Escaleno';
      }
    }

    let angleType = '';
    if (angles.A && angles.B && angles.C) {
      if (angles.A < 90 && angles.B < 90 && angles.C < 90) {
        angleType = 'Acutángulo';
      } else if (angles.A === 90 || angles.B === 90 || angles.C === 90) {
        angleType = 'Rectángulo';
      } else {
        angleType = 'Obtusángulo';
      }
    }

    // Calcular ángulos externos
    const extAngles = {
      A: angles.A ? 180 - angles.A : null,
      B: angles.B ? 180 - angles.B : null,
      C: angles.C ? 180 - angles.C : null
    };

    return {
      sides,
      angles,
      extAngles,
      perimeter,
      area,
      type,
      angleType
    };
  };

  const handleCalculate = () => {
    setError('');
    const results = calculateMissingValues();
    if (results) {
      setResults(results);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Calculadora de Triángulos Pro</h2>
      
      {error && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">{error}</div>}

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Lados</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado a</label>
              <input
                type="number"
                value={sideA}
                onChange={(e) => setSideA(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado b</label>
              <input
                type="number"
                value={sideB}
                onChange={(e) => setSideB(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Lado c</label>
              <input
                type="number"
                value={sideC}
                onChange={(e) => setSideC(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese longitud"
                min="0"
                step="0.01"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-700">Ángulos (grados)</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo A</label>
              <input
                type="number"
                value={angleA}
                onChange={(e) => setAngleA(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo B</label>
              <input
                type="number"
                value={angleB}
                onChange={(e) => setAngleB(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600">Ángulo C</label>
              <input
                type="number"
                value={angleC}
                onChange={(e) => setAngleC(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ingrese ángulo"
                min="0"
                max="180"
                step="0.1"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={handleCalculate}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200"
      >
        Calcular Propiedades
      </button>

      {results && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-3">Resultados</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-700">Lados</h4>
              <ul className="mt-2 space-y-1">
                <li>a: {results.sides.a?.toFixed(2) || 'Desconocido'}</li>
                <li>b: {results.sides.b?.toFixed(2) || 'Desconocido'}</li>
                <li>c: {results.sides.c?.toFixed(2) || 'Desconocido'}</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Internos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo A: {results.angles.A?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo B: {results.angles.B?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo C: {results.angles.C?.toFixed(1) || 'Desconocido'}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Ángulos Externos</h4>
              <ul className="mt-2 space-y-1">
                <li>Ángulo Externo A: {results.extAngles.A?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo Externo B: {results.extAngles.B?.toFixed(1) || 'Desconocido'}°</li>
                <li>Ángulo Externo C: {results.extAngles.C?.toFixed(1) || 'Desconocido'}°</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Otras Propiedades</h4>
              <ul className="mt-2 space-y-1">
                <li>Perímetro: {results.perimeter?.toFixed(2) || 'Desconocido'}</li>
                <li>Área: {results.area?.toFixed(2) || 'Desconocido'}</li>
                {results.type && <li>Tipo (lados): {results.type}</li>}
                {results.angleType && <li>Tipo (ángulos): {results.angleType}</li>}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TriangleCalculatorPro;